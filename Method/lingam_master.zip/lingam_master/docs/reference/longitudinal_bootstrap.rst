.. module:: lingam

LongitudinalBootstrapResult
===========================

.. autoclass:: LongitudinalBootstrapResult
    :members:
    :inherited-members:
