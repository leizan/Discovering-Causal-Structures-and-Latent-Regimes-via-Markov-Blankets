.. module:: lingam

DirectLiNGAM
=============

.. autoclass:: DirectLiNGAM
    :members:
    :inherited-members:
