.. module:: lingam

ICA-LiNGAM
=============

.. autoclass:: ICALiNGAM
    :members:
    :inherited-members:
