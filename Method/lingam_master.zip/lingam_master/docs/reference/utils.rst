.. module:: lingam.utils

utils
=====

.. autofunction:: print_causal_directions
.. autofunction:: print_dagc
.. autofunction:: make_prior_knowledge
.. autofunction:: remove_effect
.. autofunction:: make_dot
