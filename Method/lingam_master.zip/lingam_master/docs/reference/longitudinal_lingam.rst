.. module:: lingam

LongitudinalLiNGAM
==================

.. autoclass:: LongitudinalLiNGAM
    :members:
    :inherited-members:
