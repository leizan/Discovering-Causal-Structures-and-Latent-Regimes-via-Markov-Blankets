.. module:: lingam

BottomUpParceLiNGAM
===================

.. autoclass:: BottomUpParceLiNGAM
    :members:
    :inherited-members:
