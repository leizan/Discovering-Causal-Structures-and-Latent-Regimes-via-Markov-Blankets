.. module:: lingam

BootstrapResult
===============

.. autoclass:: BootstrapResult
    :members:
    :inherited-members:
