.. module:: lingam

VARMA-LiNGAM
=============

.. autoclass:: VARMALiNGAM
    :members:
    :inherited-members:
