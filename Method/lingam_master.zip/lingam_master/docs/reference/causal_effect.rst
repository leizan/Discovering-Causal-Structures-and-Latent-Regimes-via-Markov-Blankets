.. module:: lingam

CausalEffect
============

.. autoclass:: CausalEffect
    :members:
    :inherited-members:
