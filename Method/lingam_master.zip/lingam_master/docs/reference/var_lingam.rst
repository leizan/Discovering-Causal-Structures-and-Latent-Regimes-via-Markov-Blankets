.. module:: lingam

VAR-LiNGAM
=============

.. autoclass:: VARLiNGAM
    :members:
    :inherited-members:
