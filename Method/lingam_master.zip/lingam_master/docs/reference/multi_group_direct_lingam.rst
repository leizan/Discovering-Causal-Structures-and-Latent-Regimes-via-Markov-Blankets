.. module:: lingam

MultiGroupDirectLiNGAM
======================

.. autoclass:: MultiGroupDirectLiNGAM
    :members:
    :inherited-members:
