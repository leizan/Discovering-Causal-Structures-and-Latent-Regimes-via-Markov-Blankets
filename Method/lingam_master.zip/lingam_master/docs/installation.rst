Installation Guide
==================

To install lingam package, use `pip` as follows:

.. code-block:: bash

    $ pip install lingam

You can also install the development version of lingam package from GitHub:

.. code-block:: bash

    $ pip install git+https://github.com/cdt15/lingam.git
