Welcome to lingam's documentation!
==================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   installation
   tutorial/index
   reference/index


Indices and tables
==================

* :ref:`genindex`
